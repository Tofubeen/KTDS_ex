package com.ktdsuniversity.edu.abstractclass.abstractBar;

public class Sodas extends Drink{

	
	
	public Sodas(String name , String types, int cost ) {
		super(name , types , cost);

	}

	
	
	
	

}
