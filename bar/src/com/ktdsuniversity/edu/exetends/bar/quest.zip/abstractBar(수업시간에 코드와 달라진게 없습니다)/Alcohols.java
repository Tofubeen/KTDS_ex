package com.ktdsuniversity.edu.abstractclass.abstractBar;

public class Alcohols extends Drink{

	

	public Alcohols(String name , String types  , int cost ) {
		super(name , types , cost);

	}


	
	
	
	
}
