package com.ktdsuniversity.edu.exceptions.questexam;

public class CalculatorMain {

	public static void main(String[] args) {
		
		Calculator calculator = new Calculator();
	}
}
