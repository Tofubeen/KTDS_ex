package com.ktdsuniversity.edu.exceptions.questexam;

public class WrongOperatorException extends RuntimeException{

	public WrongOperatorException(String message) {
		super(message);
	}
}
